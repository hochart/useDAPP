export type Falsy = false | 0 | '' | null | undefined
