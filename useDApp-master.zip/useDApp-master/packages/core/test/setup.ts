import 'jsdom-global/register'
import 'mock-local-storage'
