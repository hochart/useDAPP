export const NETWORK_ARGTYPE = {
  options: ['Mainnet', 'Ropsten', 'Rinkeby', 'Goerli', 'Kovan', 'xDai', 'Localhost', 'Hardhat', 'Other'],
  control: {
    type: 'select',
  },
}
