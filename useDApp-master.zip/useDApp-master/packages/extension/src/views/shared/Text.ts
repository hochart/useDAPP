import styled from 'styled-components'

export const Text = styled.p`
  margin: 0 0 15px 0;
`
