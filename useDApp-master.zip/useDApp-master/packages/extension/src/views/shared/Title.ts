import styled from 'styled-components'

export const Title = styled.p`
  margin: 0 0 15px 0;
  font-size: 18px;
  font-weight: bold;
`
