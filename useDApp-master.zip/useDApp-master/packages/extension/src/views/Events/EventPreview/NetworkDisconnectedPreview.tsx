import React from 'react'
import { Text } from '../../shared'

export function NetworkDisconnectedPreview() {
  return <Text>Network disconnected. useDApp will not make network calls.</Text>
}
