import React from 'react'
import { Text } from '../../shared'

export function AccountDisconnectedPreview() {
  return <Text>Account disconnected. Transactions won't be signed with that account.</Text>
}
