# @usedapp/extension

## 0.3.0

### Minor Changes

- fd8e924: Remove @web3-react dependency, introduce own way of provider management

## 0.2.0

### Minor Changes

- ece010c: Support Node LTS v14 and v16, abandon v10 and v12

## 0.1.1

### Patch Changes

- b0114b5: Bump ethers version
