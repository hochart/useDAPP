# @usedapp/coingecko

## 0.4.2

### Patch Changes

- Updated dependencies [c70a76e]
- Updated dependencies [fd8e924]
  - @usedapp/core@0.10.0

## 0.4.1

### Patch Changes

- Updated dependencies [26a4314]
- Updated dependencies [3015cbd]
  - @usedapp/core@0.9.0

## 0.4.0

### Minor Changes

- ece010c: Support Node LTS v14 and v16, abandon v10 and v12

### Patch Changes

- Updated dependencies [33ade3b]
- Updated dependencies [1c257ce]
- Updated dependencies [ece010c]
- Updated dependencies [e5f0951]
  - @usedapp/core@0.8.0

## 0.3.26

### Patch Changes

- Updated dependencies [45a6dc2]
- Updated dependencies [2f37156]
- Updated dependencies [2f37156]
  - @usedapp/core@0.7.0

## 0.3.25

### Patch Changes

- Updated dependencies [5365c19]
  - @usedapp/core@0.6.0

## 0.3.24

### Patch Changes

- Updated dependencies [f5a5c47]
  - @usedapp/core@0.5.0

## 0.3.23

### Patch Changes

- c03e2ac: Don't break SSR apps with Coingecko hook
- Updated dependencies [a94fae5]
  - @usedapp/core@0.4.8

## 0.3.22

### Patch Changes

- 88c5983: Refactor coingecko
- Updated dependencies [b9304cb]
- Updated dependencies [9ab6e2f]
- Updated dependencies [9e4e4f5]
- Updated dependencies [0011fe5]
  - @usedapp/core@0.4.0
