import styled from 'styled-components'

export const Label = styled.span`
  font-size: 14px;
  line-height: 20px;
  font-weight: 700;
`
